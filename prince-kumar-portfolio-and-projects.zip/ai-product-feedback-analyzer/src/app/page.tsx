import { AnalyzerApp } from "@/components/AnalyzerApp";

export default function Home() {
  return (
    <main className="min-h-screen bg-zinc-50">
      <header className="border-b border-zinc-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-sm font-bold text-white">
              PM
            </div>
            <span className="font-semibold text-zinc-900">Feedback Analyzer</span>
          </div>
          <nav className="flex gap-6 text-sm text-zinc-600">
            <a href="/docs/PRD.md" className="hover:text-zinc-900">
              PRD
            </a>
            <a
              href="https://github.com"
              className="hover:text-zinc-900"
              target="_blank"
              rel="noopener noreferrer"
            >
              Case study
            </a>
          </nav>
        </div>
      </header>
      <AnalyzerApp />
      <footer className="border-t border-zinc-200 bg-white py-8 text-center text-sm text-zinc-500">
        Portfolio project · Turning qualitative feedback into actionable product insights
      </footer>
    </main>
  );
}
