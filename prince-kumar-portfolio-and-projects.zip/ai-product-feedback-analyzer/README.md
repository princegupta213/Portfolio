# AI Product Feedback Analyzer

**Turning 100 App Reviews Into A Prioritized Product Roadmap**

A portfolio project demonstrating end-to-end product thinking: problem discovery, PRD, MVP build, and PM-native outputs (theme clustering, sentiment analysis, ICE prioritization).

![Next.js](https://img.shields.io/badge/Next.js-15-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)

---

## Live Demo

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and click **"Or analyze 100 sample app reviews"**.

---

## The Problem

Product managers drown in qualitative feedback — app reviews, NPS comments, support tickets — but lack fast, structured ways to turn that noise into prioritized roadmap decisions.

## The Solution

Upload a CSV (or use sample data) and get:

- **Theme clusters** — Performance, UI/UX, Auth, Pricing, and 6 more
- **Sentiment breakdown** — Positive / neutral / negative per theme
- **ICE-scored roadmap** — Impact × Confidence ÷ Effort, ranked P0–P3
- **Exportable report** — Markdown for Notion, slides, or case studies

All processing runs **client-side** — your data never leaves the browser.

---

## Case Study Highlights

| Artifact | Location |
|----------|----------|
| PRD | [docs/PRD.md](docs/PRD.md) |
| Product strategy | [docs/product-strategy.md](docs/product-strategy.md) |
| User research | [docs/user-research-summary.md](docs/user-research-summary.md) |
| Sample data | [public/sample-feedback.csv](public/sample-feedback.csv) |

### Sample output (from 100 reviews)

- **Dominant themes:** Performance & Stability, UI/UX, Login & Auth
- **Top P0 initiative:** Improve app stability and performance
- **Negative sentiment:** ~45% of reviews
- **Key insight:** Auth and sync issues correlate with 1-star reviews

---

## How It Works

```
CSV Upload → Column detection → Theme matching (keywords)
           → Sentiment analysis → ICE scoring → Dashboard + Export
```

### ICE Framework

| Dimension | How it's calculated (MVP) |
|-----------|---------------------------|
| **Impact** | Heuristic by theme severity (e.g., crashes = 9) |
| **Confidence** | Mention volume + negative sentiment ratio |
| **Effort** | Estimated fix complexity by theme |
| **Score** | (Impact × Confidence) ÷ Effort |

---

## CSV Format

Your CSV needs a text column. Supported header names:

| Column | Accepted names |
|--------|----------------|
| Review text | `review`, `feedback`, `comment`, `text`, `body` |
| Rating | `rating`, `score`, `stars` |
| Date | `date`, `created`, `timestamp` |
| Source | `source`, `platform`, `channel` |

Example:

```csv
review,rating,date,source
"App crashes on startup",1,2025-01-15,App Store
"Love the design!",5,2025-01-16,Google Play
```

---

## Tech Stack

- **Next.js 15** (App Router)
- **TypeScript**
- **Tailwind CSS**
- **Recharts** (visualizations)
- **PapaParse** (CSV parsing)

No backend or API keys required for MVP.

---

## Portfolio Talking Points

Use this project in APM interviews to discuss:

1. **Problem framing** — Why qual feedback synthesis is a real PM pain
2. **Prioritization** — Why ICE over MoSCoW for ambiguous qual data
3. **MVP scoping** — Keyword clustering now, LLM themes in v2
4. **Metrics** — North star, activation, and export as value signal
5. **Tradeoffs** — Client-side privacy vs. cloud AI accuracy

---

## What's Next (v2)

- [ ] Optional OpenAI integration for custom theme discovery
- [ ] Negative-only filter toggle
- [ ] Column mapping UI for non-standard CSVs
- [ ] App Store / Zendesk integrations
- [ ] Trend analysis over time

---

## Author

Built as a portfolio project for entry-level Associate Product Manager roles.

**Contact:** [Your LinkedIn] · [Your Email]
